require 'test_helper'

class JoinTableGossipTagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
