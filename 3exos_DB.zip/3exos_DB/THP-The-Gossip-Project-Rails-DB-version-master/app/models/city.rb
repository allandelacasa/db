class City < ApplicationRecord
  belongs_to :user
end
