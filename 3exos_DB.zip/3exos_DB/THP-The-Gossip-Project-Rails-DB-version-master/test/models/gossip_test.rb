require 'test_helper'

class GossipTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
