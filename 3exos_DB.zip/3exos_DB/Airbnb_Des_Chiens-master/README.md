AIRBNB POUR LES CHIIIIENS 
Un projet validant de THP fait par DAVID YE

Une petite base de données sympathique avec l'utilisation de ActiveRecord, pour démarrer le programme touuuujours verifier en premier si les models sont up ou down avec la fameuse commande "rails db:migrate:status" selon leur etat on vas les activer avec la commande "rails db:migrate" une fois fait on peut lancer le seed avec la petite commande "rails db:seed" ce qui vas generer des "sujets" test pour notre petite BDD, pour rentrer dans la console tu fais "rails c" et a toi de jouer JEUNE POMME 